import type { Metadata, Viewport } from 'next'
import { DM_Sans, Merriweather } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { Toaster } from "sonner"
import { LocaleProvider } from "@/lib/i18n/locale-context"
import { NutriGoalProvider } from "@/lib/nutrigoal-store"
import './globals.css'

const dmSans = DM_Sans({ subsets: ["latin"], variable: "--font-dm-sans" })
const merriweather = Merriweather({ subsets: ["latin"], weight: ["400", "700"], variable: "--font-merriweather" })

export const metadata: Metadata = {
  title: 'NutriGoal - 30 plantas por semana',
  description: 'Mejora tu microbioma comiendo 30 plantas distintas por semana. Sigue tu progreso y descubre nuevos alimentos.',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#3a7d44',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body className={`${dmSans.variable} ${merriweather.variable} font-sans antialiased`}>
        <LocaleProvider>
          <NutriGoalProvider>
            {children}
            <Toaster position="bottom-center" richColors />
          </NutriGoalProvider>
        </LocaleProvider>
        <Analytics />
      </body>
    </html>
  )
}
