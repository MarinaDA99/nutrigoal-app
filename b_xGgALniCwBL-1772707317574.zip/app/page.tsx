import { Navbar } from "@/components/nutrigoal/navbar"
import { WelcomeSection } from "@/components/nutrigoal/welcome-section"
import { PlantSearch } from "@/components/nutrigoal/plant-search"
import { WeeklyDiversity } from "@/components/nutrigoal/weekly-diversity"
import { Suggestions } from "@/components/nutrigoal/suggestions"
import { WisdomBanner } from "@/components/nutrigoal/wisdom-banner"
import { CameraButton } from "@/components/nutrigoal/camera-button"

export default function Home() {
  return (
    <div className="flex min-h-dvh flex-col bg-background">
      <Navbar />
      <main className="mx-auto flex w-full max-w-lg flex-1 flex-col gap-6 pb-20">
        <WelcomeSection />
        <section className="px-4">
          <PlantSearch />
        </section>
        <WeeklyDiversity />
        <Suggestions />
        <WisdomBanner />
      </main>
      <CameraButton />
    </div>
  )
}
