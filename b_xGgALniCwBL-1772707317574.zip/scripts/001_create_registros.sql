-- Tabla de registros: tracks which plants a user has checked per week
-- Each row = one plant checked by one user in a given week

CREATE TABLE IF NOT EXISTS public.registros (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id TEXT NOT NULL,
  plant_id TEXT NOT NULL,
  week_start DATE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),

  -- Prevent duplicate entries for the same session + plant + week
  UNIQUE (session_id, plant_id, week_start)
);

-- Index for fast lookups by session + week
CREATE INDEX IF NOT EXISTS idx_registros_session_week
  ON public.registros (session_id, week_start);

-- Enable Row Level Security
ALTER TABLE public.registros ENABLE ROW LEVEL SECURITY;

-- Public read/write policy using session_id (anon key, no auth required)
-- Since NutriGoal doesn't have user auth yet, we use session_id
CREATE POLICY "Allow all operations by session_id"
  ON public.registros
  FOR ALL
  USING (true)
  WITH CHECK (true);

-- Tabla de traducciones de alimentos
-- Mirrors the concept of alimentos_traducciones for future i18n from DB

CREATE TABLE IF NOT EXISTS public.alimentos_traducciones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plant_id TEXT NOT NULL,
  locale TEXT NOT NULL DEFAULT 'es',
  name TEXT NOT NULL,
  category TEXT NOT NULL,

  UNIQUE (plant_id, locale)
);

CREATE INDEX IF NOT EXISTS idx_alimentos_locale
  ON public.alimentos_traducciones (locale);

ALTER TABLE public.alimentos_traducciones ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read on translations"
  ON public.alimentos_traducciones
  FOR SELECT
  USING (true);
