export type PlantCategory =
  | "Verduras"
  | "Frutas"
  | "Legumbres"
  | "Cereales"
  | "Frutos secos"
  | "Semillas"
  | "Hierbas y especias"
  | "Prebioticos"
  | "Probioticos"

export interface Plant {
  id: string
  name: string
  category: PlantCategory
  aliases: string[]
  isPrebiotic: boolean
  isProbiotic: boolean
}

export const PLANTS_DB: Plant[] = [
  // Verduras
  { id: "brocoli", name: "Brocoli", category: "Verduras", aliases: ["brecol"], isPrebiotic: true, isProbiotic: false },
  { id: "espinaca", name: "Espinaca", category: "Verduras", aliases: ["espinacas"], isPrebiotic: false, isProbiotic: false },
  { id: "zanahoria", name: "Zanahoria", category: "Verduras", aliases: ["zanahorias"], isPrebiotic: true, isProbiotic: false },
  { id: "tomate", name: "Tomate", category: "Verduras", aliases: ["jitomate", "tomatillo"], isPrebiotic: false, isProbiotic: false },
  { id: "pimiento", name: "Pimiento", category: "Verduras", aliases: ["pimenton", "chile", "aji", "morron"], isPrebiotic: false, isProbiotic: false },
  { id: "cebolla", name: "Cebolla", category: "Verduras", aliases: ["cebollin", "cebolleta"], isPrebiotic: true, isProbiotic: false },
  { id: "ajo", name: "Ajo", category: "Verduras", aliases: ["ajos"], isPrebiotic: true, isProbiotic: false },
  { id: "calabacin", name: "Calabacin", category: "Verduras", aliases: ["zapallito", "zucchini"], isPrebiotic: false, isProbiotic: false },
  { id: "berenjena", name: "Berenjena", category: "Verduras", aliases: ["berenjenas"], isPrebiotic: false, isProbiotic: false },
  { id: "coliflor", name: "Coliflor", category: "Verduras", aliases: [], isPrebiotic: false, isProbiotic: false },
  { id: "col", name: "Col", category: "Verduras", aliases: ["repollo", "col rizada", "kale"], isPrebiotic: false, isProbiotic: false },
  { id: "lechuga", name: "Lechuga", category: "Verduras", aliases: ["lechugas"], isPrebiotic: false, isProbiotic: false },
  { id: "pepino", name: "Pepino", category: "Verduras", aliases: ["pepinos"], isPrebiotic: false, isProbiotic: false },
  { id: "apio", name: "Apio", category: "Verduras", aliases: [], isPrebiotic: false, isProbiotic: false },
  { id: "acelga", name: "Acelga", category: "Verduras", aliases: ["acelgas"], isPrebiotic: false, isProbiotic: false },
  { id: "esparrago", name: "Esparrago", category: "Verduras", aliases: ["esparragos"], isPrebiotic: true, isProbiotic: false },
  { id: "alcachofa", name: "Alcachofa", category: "Verduras", aliases: ["alcachofas", "alcaucil"], isPrebiotic: true, isProbiotic: false },
  { id: "boniato", name: "Boniato", category: "Verduras", aliases: ["batata", "camote", "papa dulce"], isPrebiotic: false, isProbiotic: false },
  { id: "remolacha", name: "Remolacha", category: "Verduras", aliases: ["betabel", "beterraga", "betarraga"], isPrebiotic: false, isProbiotic: false },
  { id: "puerro", name: "Puerro", category: "Verduras", aliases: ["poro"], isPrebiotic: true, isProbiotic: false },

  // Frutas
  { id: "manzana", name: "Manzana", category: "Frutas", aliases: ["manzanas"], isPrebiotic: true, isProbiotic: false },
  { id: "platano", name: "Platano", category: "Frutas", aliases: ["banana", "banano", "guineo"], isPrebiotic: true, isProbiotic: false },
  { id: "aguacate", name: "Aguacate", category: "Frutas", aliases: ["palta", "avocado"], isPrebiotic: false, isProbiotic: false },
  { id: "naranja", name: "Naranja", category: "Frutas", aliases: ["naranjas", "china"], isPrebiotic: false, isProbiotic: false },
  { id: "fresa", name: "Fresa", category: "Frutas", aliases: ["fresas", "frutilla", "frutillas"], isPrebiotic: false, isProbiotic: false },
  { id: "arandano", name: "Arandano", category: "Frutas", aliases: ["arandanos", "blueberry"], isPrebiotic: false, isProbiotic: false },
  { id: "uva", name: "Uva", category: "Frutas", aliases: ["uvas"], isPrebiotic: false, isProbiotic: false },
  { id: "pera", name: "Pera", category: "Frutas", aliases: ["peras"], isPrebiotic: false, isProbiotic: false },
  { id: "kiwi", name: "Kiwi", category: "Frutas", aliases: [], isPrebiotic: false, isProbiotic: false },
  { id: "mango", name: "Mango", category: "Frutas", aliases: ["mangos"], isPrebiotic: false, isProbiotic: false },
  { id: "piña", name: "Piña", category: "Frutas", aliases: ["anana", "ananas"], isPrebiotic: false, isProbiotic: false },
  { id: "melocoton", name: "Melocoton", category: "Frutas", aliases: ["durazno", "duraznos"], isPrebiotic: false, isProbiotic: false },
  { id: "granada", name: "Granada", category: "Frutas", aliases: ["granadas"], isPrebiotic: false, isProbiotic: false },
  { id: "limon", name: "Limon", category: "Frutas", aliases: ["lima", "limas", "limones"], isPrebiotic: false, isProbiotic: false },
  { id: "papaya", name: "Papaya", category: "Frutas", aliases: ["lechosa", "fruta bomba"], isPrebiotic: false, isProbiotic: false },

  // Legumbres
  { id: "lenteja", name: "Lenteja", category: "Legumbres", aliases: ["lentejas"], isPrebiotic: true, isProbiotic: false },
  { id: "garbanzo", name: "Garbanzo", category: "Legumbres", aliases: ["garbanzos"], isPrebiotic: true, isProbiotic: false },
  { id: "judia", name: "Judia", category: "Legumbres", aliases: ["judias", "frijol", "frijoles", "poroto", "porotos", "habichuela"], isPrebiotic: false, isProbiotic: false },
  { id: "guisante", name: "Guisante", category: "Legumbres", aliases: ["guisantes", "arveja", "arvejas", "chicharos"], isPrebiotic: false, isProbiotic: false },
  { id: "soja", name: "Soja", category: "Legumbres", aliases: ["soya", "edamame"], isPrebiotic: false, isProbiotic: false },
  { id: "habas", name: "Habas", category: "Legumbres", aliases: ["haba"], isPrebiotic: false, isProbiotic: false },

  // Cereales
  { id: "avena", name: "Avena", category: "Cereales", aliases: ["hojuelas de avena", "oatmeal"], isPrebiotic: true, isProbiotic: false },
  { id: "arroz-integral", name: "Arroz integral", category: "Cereales", aliases: ["arroz moreno"], isPrebiotic: false, isProbiotic: false },
  { id: "quinoa", name: "Quinoa", category: "Cereales", aliases: ["quinua"], isPrebiotic: false, isProbiotic: false },
  { id: "cebada", name: "Cebada", category: "Cereales", aliases: ["cebadas"], isPrebiotic: true, isProbiotic: false },
  { id: "centeno", name: "Centeno", category: "Cereales", aliases: [], isPrebiotic: false, isProbiotic: false },
  { id: "trigo-sarraceno", name: "Trigo sarraceno", category: "Cereales", aliases: ["alforfon"], isPrebiotic: false, isProbiotic: false },
  { id: "mijo", name: "Mijo", category: "Cereales", aliases: [], isPrebiotic: false, isProbiotic: false },

  // Frutos secos
  { id: "nuez", name: "Nuez", category: "Frutos secos", aliases: ["nueces"], isPrebiotic: false, isProbiotic: false },
  { id: "almendra", name: "Almendra", category: "Frutos secos", aliases: ["almendras"], isPrebiotic: false, isProbiotic: false },
  { id: "pistacho", name: "Pistacho", category: "Frutos secos", aliases: ["pistachos", "pistaches"], isPrebiotic: false, isProbiotic: false },
  { id: "anacardo", name: "Anacardo", category: "Frutos secos", aliases: ["anacardos", "marañon", "merey", "cajuil", "caju"], isPrebiotic: false, isProbiotic: false },
  { id: "avellana", name: "Avellana", category: "Frutos secos", aliases: ["avellanas"], isPrebiotic: false, isProbiotic: false },
  { id: "cacahuete", name: "Cacahuete", category: "Frutos secos", aliases: ["cacahuates", "mani", "manies"], isPrebiotic: false, isProbiotic: false },

  // Semillas
  { id: "chia", name: "Chia", category: "Semillas", aliases: ["semillas de chia"], isPrebiotic: true, isProbiotic: false },
  { id: "lino", name: "Lino", category: "Semillas", aliases: ["linaza", "semillas de lino"], isPrebiotic: true, isProbiotic: false },
  { id: "girasol", name: "Semilla de girasol", category: "Semillas", aliases: ["pipas", "pepitas de girasol"], isPrebiotic: false, isProbiotic: false },
  { id: "calabaza-semilla", name: "Semilla de calabaza", category: "Semillas", aliases: ["pepitas", "pepitas de calabaza"], isPrebiotic: false, isProbiotic: false },
  { id: "sesamo", name: "Sesamo", category: "Semillas", aliases: ["ajonjoli"], isPrebiotic: false, isProbiotic: false },

  // Hierbas y especias
  { id: "jengibre", name: "Jengibre", category: "Hierbas y especias", aliases: ["kion"], isPrebiotic: false, isProbiotic: false },
  { id: "curcuma", name: "Curcuma", category: "Hierbas y especias", aliases: ["turmeric", "palillo"], isPrebiotic: false, isProbiotic: false },
  { id: "canela", name: "Canela", category: "Hierbas y especias", aliases: [], isPrebiotic: false, isProbiotic: false },
  { id: "perejil", name: "Perejil", category: "Hierbas y especias", aliases: [], isPrebiotic: false, isProbiotic: false },
  { id: "cilantro", name: "Cilantro", category: "Hierbas y especias", aliases: ["coriandro", "culantro"], isPrebiotic: false, isProbiotic: false },
  { id: "albahaca", name: "Albahaca", category: "Hierbas y especias", aliases: ["basil"], isPrebiotic: false, isProbiotic: false },
  { id: "oregano", name: "Oregano", category: "Hierbas y especias", aliases: [], isPrebiotic: false, isProbiotic: false },
  { id: "romero", name: "Romero", category: "Hierbas y especias", aliases: [], isPrebiotic: false, isProbiotic: false },

  // Prebioticos (additional dedicated prebiotic foods)
  { id: "achicoria", name: "Achicoria", category: "Prebioticos", aliases: ["raiz de achicoria"], isPrebiotic: true, isProbiotic: false },
  { id: "diente-de-leon", name: "Diente de leon", category: "Prebioticos", aliases: ["dandelion", "taraxacum"], isPrebiotic: true, isProbiotic: false },
  { id: "jicama", name: "Jicama", category: "Prebioticos", aliases: [], isPrebiotic: true, isProbiotic: false },
  { id: "yacon", name: "Yacon", category: "Prebioticos", aliases: [], isPrebiotic: true, isProbiotic: false },

  // Probioticos
  { id: "kefir", name: "Kefir", category: "Probioticos", aliases: ["kefir de leche", "kefir de agua"], isPrebiotic: false, isProbiotic: true },
  { id: "chucrut", name: "Chucrut", category: "Probioticos", aliases: ["sauerkraut", "col fermentada", "repollo fermentado"], isPrebiotic: false, isProbiotic: true },
  { id: "kimchi", name: "Kimchi", category: "Probioticos", aliases: [], isPrebiotic: false, isProbiotic: true },
  { id: "miso", name: "Miso", category: "Probioticos", aliases: ["pasta de miso"], isPrebiotic: false, isProbiotic: true },
  { id: "tempeh", name: "Tempeh", category: "Probioticos", aliases: ["tempe"], isPrebiotic: false, isProbiotic: true },
  { id: "kombucha", name: "Kombucha", category: "Probioticos", aliases: [], isPrebiotic: false, isProbiotic: true },
  { id: "yogur", name: "Yogur natural", category: "Probioticos", aliases: ["yogurt", "yogurth", "yoghurt"], isPrebiotic: false, isProbiotic: true },
]

export const CATEGORIES: PlantCategory[] = [
  "Verduras",
  "Frutas",
  "Legumbres",
  "Cereales",
  "Frutos secos",
  "Semillas",
  "Hierbas y especias",
  "Prebioticos",
  "Probioticos",
]

export function getPlantsByCategory(category: PlantCategory): Plant[] {
  return PLANTS_DB.filter((p) => p.category === category)
}

export function getPrebioticPlants(): Plant[] {
  return PLANTS_DB.filter((p) => p.isPrebiotic)
}

export function getProbioticPlants(): Plant[] {
  return PLANTS_DB.filter((p) => p.isProbiotic)
}
