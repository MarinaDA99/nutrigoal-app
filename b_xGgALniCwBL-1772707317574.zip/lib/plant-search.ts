import { PLANTS_DB, type Plant, type PlantCategory } from "./plants-db"

/**
 * Normalizes a string for comparison by removing diacritics, lowercasing,
 * and trimming whitespace. This allows "palta" to match "Aguacate" via aliases.
 */
function normalize(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
}

export interface SearchResult {
  plant: Plant
  matchedOn: "name" | "alias"
  matchedTerm: string
}

/**
 * Searches the plant database by name or alias with normalization.
 * Returns matching plants sorted by relevance (exact name > starts-with name > alias).
 */
export function searchPlants(
  query: string,
  options?: { category?: PlantCategory; excludeIds?: Set<string> }
): SearchResult[] {
  const q = normalize(query)
  if (!q) return []

  const results: SearchResult[] = []

  for (const plant of PLANTS_DB) {
    if (options?.excludeIds?.has(plant.id)) continue
    if (options?.category && plant.category !== options.category) continue

    const normalizedName = normalize(plant.name)

    // Check name match
    if (normalizedName.includes(q)) {
      results.push({ plant, matchedOn: "name", matchedTerm: plant.name })
      continue
    }

    // Check alias matches
    const matchedAlias = plant.aliases.find((alias) =>
      normalize(alias).includes(q)
    )
    if (matchedAlias) {
      results.push({ plant, matchedOn: "alias", matchedTerm: matchedAlias })
    }
  }

  // Sort: exact name match first, then startsWith, then includes, then aliases
  results.sort((a, b) => {
    const aN = normalize(a.plant.name)
    const bN = normalize(b.plant.name)

    // Exact match first
    if (aN === q && bN !== q) return -1
    if (bN === q && aN !== q) return 1

    // Name match before alias
    if (a.matchedOn === "name" && b.matchedOn === "alias") return -1
    if (a.matchedOn === "alias" && b.matchedOn === "name") return 1

    // startsWith before includes
    if (aN.startsWith(q) && !bN.startsWith(q)) return -1
    if (bN.startsWith(q) && !aN.startsWith(q)) return 1

    return a.plant.name.localeCompare(b.plant.name)
  })

  return results
}

/**
 * Resolves a user input to a canonical plant. This handles regional aliases
 * like "palta" → "Aguacate", "frutilla" → "Fresa", etc.
 */
export function resolvePlant(input: string): Plant | null {
  const q = normalize(input)
  if (!q) return null

  // Try exact name first
  const exact = PLANTS_DB.find((p) => normalize(p.name) === q)
  if (exact) return exact

  // Try exact alias
  const aliasMatch = PLANTS_DB.find((p) =>
    p.aliases.some((a) => normalize(a) === q)
  )
  if (aliasMatch) return aliasMatch

  // Try partial match
  const partial = PLANTS_DB.find(
    (p) =>
      normalize(p.name).startsWith(q) ||
      p.aliases.some((a) => normalize(a).startsWith(q))
  )
  return partial ?? null
}
