"use client"

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react"

import es from "./locales/es.json"
import en from "./locales/en.json"
import fr from "./locales/fr.json"
import it from "./locales/it.json"
import de from "./locales/de.json"

export const LOCALES = ["es", "en", "fr", "it", "de"] as const
export type Locale = (typeof LOCALES)[number]

export const LOCALE_LABELS: Record<Locale, string> = {
  es: "Espanol",
  en: "English",
  fr: "Francais",
  it: "Italiano",
  de: "Deutsch",
}

export const LOCALE_FLAGS: Record<Locale, string> = {
  es: "ES",
  en: "EN",
  fr: "FR",
  it: "IT",
  de: "DE",
}

const messages: Record<Locale, Record<string, unknown>> = { es, en, fr, it, de }

function getNestedValue(obj: Record<string, unknown>, path: string): string {
  const keys = path.split(".")
  let current: unknown = obj
  for (const key of keys) {
    if (current === null || current === undefined || typeof current !== "object") return path
    current = (current as Record<string, unknown>)[key]
  }
  return typeof current === "string" ? current : path
}

interface LocaleContextValue {
  locale: Locale
  setLocale: (locale: Locale) => void
  t: (key: string, params?: Record<string, string>) => string
}

const LocaleContext = createContext<LocaleContextValue | null>(null)

const STORAGE_KEY = "nutrigoal-locale"

export function LocaleProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>("es")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY) as Locale | null
    if (stored && LOCALES.includes(stored)) {
      setLocaleState(stored)
    }
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted) {
      document.documentElement.lang = locale
    }
  }, [locale, mounted])

  const setLocale = useCallback((newLocale: Locale) => {
    setLocaleState(newLocale)
    localStorage.setItem(STORAGE_KEY, newLocale)
  }, [])

  const t = useCallback(
    (key: string, params?: Record<string, string>): string => {
      let value = getNestedValue(messages[locale], key)
      if (params) {
        for (const [param, replacement] of Object.entries(params)) {
          value = value.replace(`{{${param}}}`, replacement)
        }
      }
      return value
    },
    [locale]
  )

  return (
    <LocaleContext.Provider value={{ locale, setLocale, t }}>
      {children}
    </LocaleContext.Provider>
  )
}

export function useTranslation() {
  const context = useContext(LocaleContext)
  if (!context) {
    throw new Error("useTranslation must be used within a LocaleProvider")
  }
  return context
}
