import type { Locale } from "./locale-context"

/**
 * Plant name translations keyed by plant ID and locale.
 * Mirrors the concept of an `alimentos_traducciones` database table.
 * Falls back to Spanish if a translation is missing.
 */
const plantNames: Record<string, Record<Locale, string>> = {
  // Verduras
  brocoli:        { es: "Brocoli", en: "Broccoli", fr: "Brocoli", it: "Broccoli", de: "Brokkoli" },
  espinaca:       { es: "Espinaca", en: "Spinach", fr: "Epinard", it: "Spinaci", de: "Spinat" },
  zanahoria:      { es: "Zanahoria", en: "Carrot", fr: "Carotte", it: "Carota", de: "Karotte" },
  tomate:         { es: "Tomate", en: "Tomato", fr: "Tomate", it: "Pomodoro", de: "Tomate" },
  pimiento:       { es: "Pimiento", en: "Bell pepper", fr: "Poivron", it: "Peperone", de: "Paprika" },
  cebolla:        { es: "Cebolla", en: "Onion", fr: "Oignon", it: "Cipolla", de: "Zwiebel" },
  ajo:            { es: "Ajo", en: "Garlic", fr: "Ail", it: "Aglio", de: "Knoblauch" },
  calabacin:      { es: "Calabacin", en: "Zucchini", fr: "Courgette", it: "Zucchina", de: "Zucchini" },
  berenjena:      { es: "Berenjena", en: "Eggplant", fr: "Aubergine", it: "Melanzana", de: "Aubergine" },
  coliflor:       { es: "Coliflor", en: "Cauliflower", fr: "Chou-fleur", it: "Cavolfiore", de: "Blumenkohl" },
  col:            { es: "Col", en: "Cabbage", fr: "Chou", it: "Cavolo", de: "Kohl" },
  lechuga:        { es: "Lechuga", en: "Lettuce", fr: "Laitue", it: "Lattuga", de: "Salat" },
  pepino:         { es: "Pepino", en: "Cucumber", fr: "Concombre", it: "Cetriolo", de: "Gurke" },
  apio:           { es: "Apio", en: "Celery", fr: "Celeri", it: "Sedano", de: "Sellerie" },
  acelga:         { es: "Acelga", en: "Chard", fr: "Blette", it: "Bietola", de: "Mangold" },
  esparrago:      { es: "Esparrago", en: "Asparagus", fr: "Asperge", it: "Asparago", de: "Spargel" },
  alcachofa:      { es: "Alcachofa", en: "Artichoke", fr: "Artichaut", it: "Carciofo", de: "Artischocke" },
  boniato:        { es: "Boniato", en: "Sweet potato", fr: "Patate douce", it: "Patata dolce", de: "Susskartoffel" },
  remolacha:      { es: "Remolacha", en: "Beetroot", fr: "Betterave", it: "Barbabietola", de: "Rote Bete" },
  puerro:         { es: "Puerro", en: "Leek", fr: "Poireau", it: "Porro", de: "Lauch" },

  // Frutas
  manzana:        { es: "Manzana", en: "Apple", fr: "Pomme", it: "Mela", de: "Apfel" },
  platano:        { es: "Platano", en: "Banana", fr: "Banane", it: "Banana", de: "Banane" },
  aguacate:       { es: "Aguacate", en: "Avocado", fr: "Avocat", it: "Avocado", de: "Avocado" },
  naranja:        { es: "Naranja", en: "Orange", fr: "Orange", it: "Arancia", de: "Orange" },
  fresa:          { es: "Fresa", en: "Strawberry", fr: "Fraise", it: "Fragola", de: "Erdbeere" },
  arandano:       { es: "Arandano", en: "Blueberry", fr: "Myrtille", it: "Mirtillo", de: "Blaubeere" },
  uva:            { es: "Uva", en: "Grape", fr: "Raisin", it: "Uva", de: "Traube" },
  pera:           { es: "Pera", en: "Pear", fr: "Poire", it: "Pera", de: "Birne" },
  kiwi:           { es: "Kiwi", en: "Kiwi", fr: "Kiwi", it: "Kiwi", de: "Kiwi" },
  mango:          { es: "Mango", en: "Mango", fr: "Mangue", it: "Mango", de: "Mango" },
  "piña":         { es: "Piña", en: "Pineapple", fr: "Ananas", it: "Ananas", de: "Ananas" },
  melocoton:      { es: "Melocoton", en: "Peach", fr: "Peche", it: "Pesca", de: "Pfirsich" },
  granada:        { es: "Granada", en: "Pomegranate", fr: "Grenade", it: "Melograno", de: "Granatapfel" },
  limon:          { es: "Limon", en: "Lemon", fr: "Citron", it: "Limone", de: "Zitrone" },
  papaya:         { es: "Papaya", en: "Papaya", fr: "Papaye", it: "Papaia", de: "Papaya" },

  // Legumbres
  lenteja:        { es: "Lenteja", en: "Lentil", fr: "Lentille", it: "Lenticchia", de: "Linse" },
  garbanzo:       { es: "Garbanzo", en: "Chickpea", fr: "Pois chiche", it: "Cece", de: "Kichererbse" },
  judia:          { es: "Judia", en: "Bean", fr: "Haricot", it: "Fagiolo", de: "Bohne" },
  guisante:       { es: "Guisante", en: "Pea", fr: "Petit pois", it: "Pisello", de: "Erbse" },
  soja:           { es: "Soja", en: "Soybean", fr: "Soja", it: "Soia", de: "Sojabohne" },
  habas:          { es: "Habas", en: "Broad beans", fr: "Feves", it: "Fave", de: "Saubohnen" },

  // Cereales
  avena:          { es: "Avena", en: "Oats", fr: "Avoine", it: "Avena", de: "Hafer" },
  "arroz-integral": { es: "Arroz integral", en: "Brown rice", fr: "Riz complet", it: "Riso integrale", de: "Vollkornreis" },
  quinoa:         { es: "Quinoa", en: "Quinoa", fr: "Quinoa", it: "Quinoa", de: "Quinoa" },
  cebada:         { es: "Cebada", en: "Barley", fr: "Orge", it: "Orzo", de: "Gerste" },
  centeno:        { es: "Centeno", en: "Rye", fr: "Seigle", it: "Segale", de: "Roggen" },
  "trigo-sarraceno": { es: "Trigo sarraceno", en: "Buckwheat", fr: "Sarrasin", it: "Grano saraceno", de: "Buchweizen" },
  mijo:           { es: "Mijo", en: "Millet", fr: "Millet", it: "Miglio", de: "Hirse" },

  // Frutos secos
  nuez:           { es: "Nuez", en: "Walnut", fr: "Noix", it: "Noce", de: "Walnuss" },
  almendra:       { es: "Almendra", en: "Almond", fr: "Amande", it: "Mandorla", de: "Mandel" },
  pistacho:       { es: "Pistacho", en: "Pistachio", fr: "Pistache", it: "Pistacchio", de: "Pistazie" },
  anacardo:       { es: "Anacardo", en: "Cashew", fr: "Noix de cajou", it: "Anacardo", de: "Cashewnuss" },
  avellana:       { es: "Avellana", en: "Hazelnut", fr: "Noisette", it: "Nocciola", de: "Haselnuss" },
  cacahuete:      { es: "Cacahuete", en: "Peanut", fr: "Cacahuete", it: "Arachide", de: "Erdnuss" },

  // Semillas
  chia:           { es: "Chia", en: "Chia", fr: "Chia", it: "Chia", de: "Chia" },
  lino:           { es: "Lino", en: "Flaxseed", fr: "Lin", it: "Lino", de: "Leinsamen" },
  girasol:        { es: "Semilla de girasol", en: "Sunflower seed", fr: "Graine de tournesol", it: "Semi di girasole", de: "Sonnenblumenkern" },
  "calabaza-semilla": { es: "Semilla de calabaza", en: "Pumpkin seed", fr: "Graine de courge", it: "Semi di zucca", de: "Kurbiskern" },
  sesamo:         { es: "Sesamo", en: "Sesame", fr: "Sesame", it: "Sesamo", de: "Sesam" },

  // Hierbas y especias
  jengibre:       { es: "Jengibre", en: "Ginger", fr: "Gingembre", it: "Zenzero", de: "Ingwer" },
  curcuma:        { es: "Curcuma", en: "Turmeric", fr: "Curcuma", it: "Curcuma", de: "Kurkuma" },
  canela:         { es: "Canela", en: "Cinnamon", fr: "Cannelle", it: "Cannella", de: "Zimt" },
  perejil:        { es: "Perejil", en: "Parsley", fr: "Persil", it: "Prezzemolo", de: "Petersilie" },
  cilantro:       { es: "Cilantro", en: "Cilantro", fr: "Coriandre", it: "Coriandolo", de: "Koriander" },
  albahaca:       { es: "Albahaca", en: "Basil", fr: "Basilic", it: "Basilico", de: "Basilikum" },
  oregano:        { es: "Oregano", en: "Oregano", fr: "Origan", it: "Origano", de: "Oregano" },
  romero:         { es: "Romero", en: "Rosemary", fr: "Romarin", it: "Rosmarino", de: "Rosmarin" },

  // Prebioticos
  achicoria:      { es: "Achicoria", en: "Chicory", fr: "Chicoree", it: "Cicoria", de: "Zichorie" },
  "diente-de-leon": { es: "Diente de leon", en: "Dandelion", fr: "Pissenlit", it: "Tarassaco", de: "Lowenzahn" },
  jicama:         { es: "Jicama", en: "Jicama", fr: "Jicama", it: "Jicama", de: "Jicama" },
  yacon:          { es: "Yacon", en: "Yacon", fr: "Yacon", it: "Yacon", de: "Yacon" },

  // Probioticos
  kefir:          { es: "Kefir", en: "Kefir", fr: "Kefir", it: "Kefir", de: "Kefir" },
  chucrut:        { es: "Chucrut", en: "Sauerkraut", fr: "Choucroute", it: "Crauti", de: "Sauerkraut" },
  kimchi:         { es: "Kimchi", en: "Kimchi", fr: "Kimchi", it: "Kimchi", de: "Kimchi" },
  miso:           { es: "Miso", en: "Miso", fr: "Miso", it: "Miso", de: "Miso" },
  tempeh:         { es: "Tempeh", en: "Tempeh", fr: "Tempeh", it: "Tempeh", de: "Tempeh" },
  kombucha:       { es: "Kombucha", en: "Kombucha", fr: "Kombucha", it: "Kombucha", de: "Kombucha" },
  yogur:          { es: "Yogur natural", en: "Natural yogurt", fr: "Yaourt nature", it: "Yogurt naturale", de: "Naturjoghurt" },
}

/**
 * Get the translated plant name for a given ID and locale.
 * Falls back to Spanish, then to the raw ID.
 */
export function getPlantName(plantId: string, locale: Locale): string {
  const entry = plantNames[plantId]
  if (!entry) return plantId
  return entry[locale] ?? entry.es ?? plantId
}

/**
 * Get all plant translations for a given locale (for search indexing).
 */
export function getAllPlantTranslations(locale: Locale): Record<string, string> {
  const result: Record<string, string> = {}
  for (const [id, translations] of Object.entries(plantNames)) {
    result[id] = translations[locale] ?? translations.es ?? id
  }
  return result
}
