"use client"

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useReducer,
  type ReactNode,
} from "react"
import { PLANTS_DB } from "./plants-db"

const STORAGE_KEY = "nutrigoal-checked"
const WEEK_KEY = "nutrigoal-week-start"
const GOAL = 30

/* ---------- helpers ---------- */

function getMonday(d: Date): string {
  const date = new Date(d)
  const day = date.getDay()
  const diff = date.getDate() - day + (day === 0 ? -6 : 1)
  date.setDate(diff)
  date.setHours(0, 0, 0, 0)
  return date.toISOString().slice(0, 10)
}

function loadChecked(): string[] {
  if (typeof window === "undefined") return []
  try {
    const currentWeek = getMonday(new Date())
    const storedWeek = localStorage.getItem(WEEK_KEY)

    if (storedWeek !== currentWeek) {
      localStorage.setItem(WEEK_KEY, currentWeek)
      localStorage.removeItem(STORAGE_KEY)
      return []
    }

    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : []
  } catch {
    return []
  }
}

function saveChecked(ids: string[]) {
  if (typeof window === "undefined") return
  localStorage.setItem(STORAGE_KEY, JSON.stringify(ids))
  localStorage.setItem(WEEK_KEY, getMonday(new Date()))
}

/* ---------- state ---------- */

interface NutriState {
  checkedIds: string[]
  mounted: boolean
}

type NutriAction =
  | { type: "INIT"; ids: string[] }
  | { type: "ADD"; id: string }
  | { type: "REMOVE"; id: string }
  | { type: "TOGGLE"; id: string }
  | { type: "RESET" }

function reducer(state: NutriState, action: NutriAction): NutriState {
  switch (action.type) {
    case "INIT":
      return { checkedIds: action.ids, mounted: true }
    case "ADD": {
      if (state.checkedIds.includes(action.id)) return state
      const next = [...state.checkedIds, action.id]
      saveChecked(next)
      return { ...state, checkedIds: next }
    }
    case "REMOVE": {
      const next = state.checkedIds.filter((id) => id !== action.id)
      saveChecked(next)
      return { ...state, checkedIds: next }
    }
    case "TOGGLE": {
      const exists = state.checkedIds.includes(action.id)
      const next = exists
        ? state.checkedIds.filter((id) => id !== action.id)
        : [...state.checkedIds, action.id]
      saveChecked(next)
      return { ...state, checkedIds: next }
    }
    case "RESET":
      saveChecked([])
      return { ...state, checkedIds: [] }
    default:
      return state
  }
}

/* ---------- derived ---------- */

function deriveCounts(checkedIds: string[]) {
  const checkedSet = new Set(checkedIds)
  let prebiotics = 0
  let probiotics = 0

  for (const plant of PLANTS_DB) {
    if (checkedSet.has(plant.id)) {
      if (plant.isPrebiotic) prebiotics++
      if (plant.isProbiotic) probiotics++
    }
  }

  return {
    total: checkedIds.length,
    goal: GOAL,
    prebiotics,
    probiotics,
    prebioticsTotal: PLANTS_DB.filter((p) => p.isPrebiotic).length,
    probioticsTotal: PLANTS_DB.filter((p) => p.isProbiotic).length,
  }
}

/* ---------- context ---------- */

interface NutriContextValue {
  checkedIds: string[]
  isChecked: (id: string) => boolean
  addPlant: (id: string) => void
  removePlant: (id: string) => void
  togglePlant: (id: string) => void
  resetWeek: () => void
  counts: ReturnType<typeof deriveCounts>
  mounted: boolean
}

const NutriContext = createContext<NutriContextValue | null>(null)

export function NutriGoalProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, {
    checkedIds: [],
    mounted: false,
  })

  useEffect(() => {
    dispatch({ type: "INIT", ids: loadChecked() })
  }, [])

  const isChecked = useCallback(
    (id: string) => state.checkedIds.includes(id),
    [state.checkedIds]
  )
  const addPlant = useCallback((id: string) => dispatch({ type: "ADD", id }), [])
  const removePlant = useCallback(
    (id: string) => dispatch({ type: "REMOVE", id }),
    []
  )
  const togglePlant = useCallback(
    (id: string) => dispatch({ type: "TOGGLE", id }),
    []
  )
  const resetWeek = useCallback(() => dispatch({ type: "RESET" }), [])

  const counts = deriveCounts(state.checkedIds)

  return (
    <NutriContext.Provider
      value={{
        checkedIds: state.checkedIds,
        isChecked,
        addPlant,
        removePlant,
        togglePlant,
        resetWeek,
        counts,
        mounted: state.mounted,
      }}
    >
      {children}
    </NutriContext.Provider>
  )
}

export function useNutriGoal() {
  const context = useContext(NutriContext)
  if (!context) {
    throw new Error("useNutriGoal must be used within a NutriGoalProvider")
  }
  return context
}
