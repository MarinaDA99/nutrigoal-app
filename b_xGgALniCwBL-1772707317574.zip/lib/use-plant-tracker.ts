"use client"

import useSWR from "swr"
import type { Plant } from "./plants-db"

const TRACKER_KEY = "nutrigoal-tracker"

export interface TrackerState {
  tracked: Plant[]
}

const defaultState: TrackerState = {
  tracked: [],
}

function getInitialState(): TrackerState {
  return defaultState
}

/**
 * SWR-based global tracker for plants consumed this week.
 * State syncs automatically between all components that call this hook.
 */
export function usePlantTracker() {
  const { data, mutate } = useSWR<TrackerState>(TRACKER_KEY, getInitialState, {
    fallbackData: defaultState,
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
  })

  const state = data ?? defaultState

  const addPlant = (plant: Plant) => {
    const isAlreadyTracked = state.tracked.some((p) => p.id === plant.id)
    if (isAlreadyTracked) return

    const newState: TrackerState = {
      ...state,
      tracked: [...state.tracked, plant],
    }
    mutate(newState, { revalidate: false })
  }

  const removePlant = (plantId: string) => {
    const newState: TrackerState = {
      ...state,
      tracked: state.tracked.filter((p) => p.id !== plantId),
    }
    mutate(newState, { revalidate: false })
  }

  const isTracked = (plantId: string) =>
    state.tracked.some((p) => p.id === plantId)

  const totalCount = state.tracked.length
  const prebioticCount = state.tracked.filter((p) => p.isPrebiotic).length
  const probioticCount = state.tracked.filter((p) => p.isProbiotic).length
  const trackedIds = new Set(state.tracked.map((p) => p.id))

  const reset = () => {
    mutate(defaultState, { revalidate: false })
  }

  return {
    tracked: state.tracked,
    trackedIds,
    totalCount,
    prebioticCount,
    probioticCount,
    addPlant,
    removePlant,
    isTracked,
    reset,
  }
}
