"use client"

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  useTranslation,
  LOCALES,
  LOCALE_LABELS,
  LOCALE_FLAGS,
  type Locale,
} from "@/lib/i18n/locale-context"

export function LanguageSelector() {
  const { locale, setLocale, t } = useTranslation()

  return (
    <div className="flex items-center gap-3">
      <label className="text-sm font-medium text-card-foreground" htmlFor="language-select">
        {t("profile.language")}
      </label>
      <Select value={locale} onValueChange={(v) => setLocale(v as Locale)}>
        <SelectTrigger id="language-select" className="w-36">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {LOCALES.map((loc) => (
            <SelectItem key={loc} value={loc}>
              <span className="flex items-center gap-2">
                <span className="font-mono text-xs text-muted-foreground">{LOCALE_FLAGS[loc]}</span>
                <span>{LOCALE_LABELS[loc]}</span>
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}
