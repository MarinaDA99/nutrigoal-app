"use client"

import { Sprout } from "lucide-react"
import { useTranslation } from "@/lib/i18n/locale-context"

export function WelcomeSection() {
  const { t } = useTranslation()

  return (
    <section className="flex flex-col gap-1 px-4 pt-6">
      <div className="flex items-center gap-2">
        <Sprout className="h-5 w-5 text-accent" />
        <p className="text-sm font-medium text-muted-foreground">
          {t("welcome.greeting", { name: "Laura" })}
        </p>
      </div>
      <h1 className="text-4xl font-bold tracking-tight text-foreground text-balance">
        {t("welcome.title")}
      </h1>
      <p className="text-sm leading-relaxed text-muted-foreground">
        {t("welcome.subtitle")}
      </p>
    </section>
  )
}
