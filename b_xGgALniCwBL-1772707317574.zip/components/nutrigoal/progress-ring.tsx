"use client"

import { useTranslation } from "@/lib/i18n/locale-context"

interface ProgressRingProps {
  current: number
  total: number
  size?: number
  strokeWidth?: number
}

export function ProgressRing({
  current,
  total,
  size = 140,
  strokeWidth = 12,
}: ProgressRingProps) {
  const radius = (size - strokeWidth) / 2
  const circumference = 2 * Math.PI * radius
  const percentage = Math.min(current / total, 1)
  const offset = circumference - percentage * circumference
  const { t } = useTranslation()

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg
        width={size}
        height={size}
        className="-rotate-90"
        aria-hidden="true"
      >
        {/* Background track */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          className="text-muted"
        />
        {/* Progress arc */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="text-primary transition-all duration-700 ease-out"
        />
      </svg>
      {/* Center text */}
      <div className="absolute flex flex-col items-center">
        <span className="text-2xl font-bold text-foreground">{current}</span>
        <span className="text-xs font-medium text-muted-foreground">
          {t("weekly.of")} {total}
        </span>
      </div>
    </div>
  )
}
