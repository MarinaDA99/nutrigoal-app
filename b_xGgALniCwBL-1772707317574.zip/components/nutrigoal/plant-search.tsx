"use client"

import { useState, useMemo, useRef, useEffect } from "react"
import { Search, Check, Plus, Leaf, FlaskConical } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { searchPlants, type SearchResult } from "@/lib/plant-search"
import { useNutriGoal } from "@/lib/nutrigoal-store"
import { useTranslation } from "@/lib/i18n/locale-context"
import { getPlantName } from "@/lib/i18n/plant-translations"
import { toast } from "sonner"

export function PlantSearch() {
  const [query, setQuery] = useState("")
  const [isFocused, setIsFocused] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const { isChecked, togglePlant } = useNutriGoal()
  const { t, locale } = useTranslation()

  const results = useMemo<SearchResult[]>(() => {
    if (query.trim().length < 2) return []
    return searchPlants(query).slice(0, 8)
  }, [query])

  const showDropdown = isFocused && query.trim().length >= 2

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsFocused(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  function handleToggle(result: SearchResult) {
    const name = getPlantName(result.plant.id, locale)
    const checked = isChecked(result.plant.id)
    togglePlant(result.plant.id)
    if (checked) {
      toast(t("suggestions.removed", { name }))
    } else {
      toast(t("suggestions.added", { name }))
    }
  }

  return (
    <div ref={containerRef} className="relative">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder={t("search.placeholder")}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsFocused(true)}
          className="pl-10 bg-card border-border"
        />
      </div>

      {showDropdown && (
        <div className="absolute z-50 top-full mt-1 w-full rounded-lg border border-border bg-card shadow-lg overflow-hidden">
          {results.length === 0 ? (
            <div className="px-4 py-6 text-center text-sm text-muted-foreground">
              {t("search.noResults")}
            </div>
          ) : (
            <ul className="max-h-64 overflow-y-auto" role="listbox">
              {results.map((r) => {
                const checked = isChecked(r.plant.id)
                const name = getPlantName(r.plant.id, locale)
                return (
                  <li key={r.plant.id} role="option" aria-selected={checked}>
                    <button
                      type="button"
                      onClick={() => handleToggle(r)}
                      className="flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-muted/50 transition-colors"
                    >
                      <div
                        className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
                          checked
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {checked ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={`text-sm font-medium ${checked ? "text-primary" : "text-card-foreground"}`}>
                            {name}
                          </span>
                          {r.matchedOn === "alias" && (
                            <span className="text-xs text-muted-foreground">
                              ({t("search.matchedAs")} &ldquo;{r.matchedTerm}&rdquo;)
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <Badge variant="secondary" className="text-xs px-1.5 py-0">
                            {t(`categories.${r.plant.category}`)}
                          </Badge>
                          {r.plant.isPrebiotic && (
                            <span className="flex items-center gap-0.5 text-xs text-accent">
                              <Leaf className="h-3 w-3" /> Pre
                            </span>
                          )}
                          {r.plant.isProbiotic && (
                            <span className="flex items-center gap-0.5 text-xs text-accent">
                              <FlaskConical className="h-3 w-3" /> Pro
                            </span>
                          )}
                        </div>
                      </div>
                    </button>
                  </li>
                )
              })}
            </ul>
          )}
        </div>
      )}
    </div>
  )
}
