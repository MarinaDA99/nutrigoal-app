"use client"

import { BookOpen } from "lucide-react"
import { useTranslation } from "@/lib/i18n/locale-context"

export function WisdomBanner() {
  const { t } = useTranslation()

  return (
    <section className="px-4 pb-8">
      <div className="flex flex-col gap-3 rounded-2xl bg-primary/10 px-5 py-5">
        <div className="flex items-center gap-2">
          <BookOpen className="h-4 w-4 text-primary" />
          <span className="text-sm font-semibold text-foreground">
            {t("wisdom.title")}
          </span>
        </div>
        <p className="font-serif text-sm italic leading-relaxed text-muted-foreground">
          &ldquo;{t("wisdom.quote")}&rdquo;
        </p>
      </div>
    </section>
  )
}
