"use client"

import { useState } from "react"
import { Leaf, Menu, X } from "lucide-react"
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
} from "@/components/ui/sheet"
import { useTranslation } from "@/lib/i18n/locale-context"
import { LanguageSelector } from "./language-selector"

const navKeys = [
  { key: "nav.home", href: "#" },
  { key: "nav.history", href: "#historial" },
  { key: "nav.achievements", href: "#logros" },
  { key: "nav.profile", href: "#perfil" },
]

export function Navbar() {
  const [open, setOpen] = useState(false)
  const { t } = useTranslation()

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-card/80 backdrop-blur-md">
      <nav className="mx-auto flex max-w-lg items-center justify-between px-4 py-3">
        <a href="#" className="flex items-center gap-2" aria-label="NutriGoal">
          <Leaf className="h-6 w-6 text-primary" />
          <span className="text-lg font-bold text-foreground">NutriGoal</span>
        </a>

        {/* Desktop nav */}
        <div className="hidden items-center gap-6 md:flex">
          <ul className="flex items-center gap-6">
            {navKeys.map((link) => (
              <li key={link.key}>
                <a
                  href={link.href}
                  className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
                >
                  {t(link.key)}
                </a>
              </li>
            ))}
          </ul>
          <LanguageSelector />
        </div>

        {/* Mobile hamburger */}
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <button
              className="flex items-center justify-center rounded-lg p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground md:hidden"
              aria-label={t("nav.home")}
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </SheetTrigger>
          <SheetContent side="right" className="w-64 bg-card">
            <SheetTitle className="sr-only">Menu</SheetTitle>
            <nav className="mt-8 flex flex-col gap-4 px-2">
              {navKeys.map((link) => (
                <a
                  key={link.key}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="rounded-lg px-4 py-3 text-base font-medium text-foreground transition-colors hover:bg-muted"
                >
                  {t(link.key)}
                </a>
              ))}
              <div className="mt-4 border-t border-border pt-4 px-4">
                <LanguageSelector />
              </div>
            </nav>
          </SheetContent>
        </Sheet>
      </nav>
    </header>
  )
}
