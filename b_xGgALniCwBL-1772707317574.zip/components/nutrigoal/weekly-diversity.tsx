"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ProgressRing } from "./progress-ring"
import { Check, Circle, TrendingUp } from "lucide-react"
import { useNutriGoal } from "@/lib/nutrigoal-store"
import { useTranslation } from "@/lib/i18n/locale-context"

interface MetricProps {
  label: string
  current: number
  total: number
}

function MetricRow({ label, current, total }: MetricProps) {
  const percentage = total > 0 ? Math.round((current / total) * 100) : 0
  const checks = Array.from({ length: total }, (_, i) => i < current)

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-foreground">{label}</span>
        <span className="text-xs font-semibold text-muted-foreground">
          {current}/{total}
        </span>
      </div>
      <Progress value={percentage} className="h-2" />
      <div className="flex flex-wrap gap-1.5">
        {checks.map((filled, i) =>
          filled ? (
            <div
              key={i}
              className="flex h-5 w-5 items-center justify-center rounded-full bg-primary"
            >
              <Check className="h-3 w-3 text-primary-foreground" />
            </div>
          ) : (
            <div
              key={i}
              className="flex h-5 w-5 items-center justify-center rounded-full border-2 border-muted"
            >
              <Circle className="h-2 w-2 text-muted" />
            </div>
          )
        )}
      </div>
    </div>
  )
}

export function WeeklyDiversity() {
  const { counts } = useNutriGoal()
  const { t } = useTranslation()

  return (
    <Card className="mx-4 border-border/60 shadow-md">
      <CardHeader>
        <div className="flex items-center gap-2">
          <TrendingUp className="h-4 w-4 text-primary" />
          <CardTitle className="text-base">{t("weekly.title")}</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-6">
          {/* Left: Donut chart */}
          <div className="flex shrink-0 items-center justify-center">
            <ProgressRing current={counts.total} total={counts.goal} />
          </div>

          {/* Right: Metrics */}
          <div className="flex flex-1 flex-col gap-5">
            <MetricRow
              label={t("weekly.prebiotics")}
              current={counts.prebiotics}
              total={counts.prebioticsTotal}
            />
            <MetricRow
              label={t("weekly.probiotics")}
              current={counts.probiotics}
              total={counts.probioticsTotal}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
