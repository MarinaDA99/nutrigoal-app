"use client"

import { useState, useCallback } from "react"
import { Camera, ScanLine, Leaf } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog"
import { PLANTS_DB } from "@/lib/plants-db"
import { useNutriGoal } from "@/lib/nutrigoal-store"
import { useTranslation } from "@/lib/i18n/locale-context"
import { getPlantName } from "@/lib/i18n/plant-translations"
import { toast } from "sonner"

type Phase = "idle" | "scanning" | "detected"

export function CameraButton() {
  const [open, setOpen] = useState(false)
  const [phase, setPhase] = useState<Phase>("idle")
  const [detectedPlantId, setDetectedPlantId] = useState<string | null>(null)
  const { checkedIds, addPlant } = useNutriGoal()
  const { t, locale } = useTranslation()

  const startScan = useCallback(() => {
    setOpen(true)
    setPhase("scanning")
    setDetectedPlantId(null)

    // Pick a random unchecked plant (or any if all checked)
    const unchecked = PLANTS_DB.filter((p) => !checkedIds.includes(p.id))
    const pool = unchecked.length > 0 ? unchecked : PLANTS_DB
    const pick = pool[Math.floor(Math.random() * pool.length)]

    setTimeout(() => {
      setDetectedPlantId(pick.id)
      setPhase("detected")
    }, 2000)
  }, [checkedIds])

  function handleAdd() {
    if (!detectedPlantId) return
    addPlant(detectedPlantId)
    const name = getPlantName(detectedPlantId, locale)
    toast(t("camera.success", { name }))
    setOpen(false)
    setPhase("idle")
  }

  function handleClose() {
    setOpen(false)
    setPhase("idle")
  }

  const detectedName = detectedPlantId
    ? getPlantName(detectedPlantId, locale)
    : ""
  const detectedPlant = detectedPlantId
    ? PLANTS_DB.find((p) => p.id === detectedPlantId)
    : null

  return (
    <>
      <Button
        onClick={startScan}
        size="lg"
        className="fixed bottom-6 right-6 z-40 h-14 w-14 rounded-full shadow-lg p-0"
        aria-label={t("camera.button")}
      >
        <Camera className="h-6 w-6" />
      </Button>

      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>{t("camera.title")}</DialogTitle>
            <DialogDescription>{t("camera.description")}</DialogDescription>
          </DialogHeader>

          <div className="flex flex-col items-center gap-4 py-6">
            {phase === "scanning" && (
              <div className="flex flex-col items-center gap-3">
                <div className="relative flex h-24 w-24 items-center justify-center">
                  <div className="absolute inset-0 rounded-full border-4 border-primary/30 animate-ping" />
                  <div className="absolute inset-2 rounded-full border-2 border-primary/50 animate-pulse" />
                  <ScanLine className="h-10 w-10 text-primary animate-pulse" />
                </div>
                <p className="text-sm text-muted-foreground font-medium animate-pulse">
                  {t("camera.simulating")}
                </p>
              </div>
            )}

            {phase === "detected" && detectedPlant && (
              <div className="flex flex-col items-center gap-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/10">
                  <Leaf className="h-10 w-10 text-primary" />
                </div>
                <div className="text-center">
                  <p className="text-xs uppercase tracking-wider text-muted-foreground mb-1">
                    {t("camera.detected")}
                  </p>
                  <p className="text-xl font-semibold text-card-foreground">
                    {detectedName}
                  </p>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    {t(`categories.${detectedPlant.category}`)}
                  </p>
                </div>
                <div className="flex gap-3 w-full">
                  <Button variant="outline" onClick={handleClose} className="flex-1">
                    {t("camera.cancel")}
                  </Button>
                  <Button onClick={handleAdd} className="flex-1">
                    {t("camera.add")}
                  </Button>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
