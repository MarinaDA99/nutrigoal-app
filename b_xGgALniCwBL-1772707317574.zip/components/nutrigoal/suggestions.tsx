"use client"

import { useMemo } from "react"
import { Nut, Milk, Wheat, Apple, Check, Sparkles } from "lucide-react"
import { PLANTS_DB } from "@/lib/plants-db"
import { useNutriGoal } from "@/lib/nutrigoal-store"
import { useTranslation } from "@/lib/i18n/locale-context"
import { getPlantName } from "@/lib/i18n/plant-translations"
import { toast } from "sonner"
import type { LucideIcon } from "lucide-react"

const SUGGESTION_IDS = ["nuez", "kefir", "avena", "manzana"]
const ICON_MAP: Record<string, LucideIcon> = {
  nuez: Nut,
  kefir: Milk,
  avena: Wheat,
  manzana: Apple,
}
const COLOR_MAP: Record<string, string> = {
  nuez: "bg-secondary text-secondary-foreground",
  kefir: "bg-primary/10 text-primary",
  avena: "bg-secondary text-secondary-foreground",
  manzana: "bg-primary/10 text-primary",
}

export function Suggestions() {
  const { isChecked, togglePlant } = useNutriGoal()
  const { t, locale } = useTranslation()

  const items = useMemo(() => {
    return SUGGESTION_IDS.map((id) => {
      const plant = PLANTS_DB.find((p) => p.id === id)
      return {
        id,
        name: getPlantName(id, locale),
        icon: ICON_MAP[id] ?? Apple,
        color: COLOR_MAP[id] ?? "bg-secondary text-secondary-foreground",
        plant,
      }
    })
  }, [locale])

  function handleToggle(id: string, name: string) {
    const checked = isChecked(id)
    togglePlant(id)
    if (checked) {
      toast(t("suggestions.removed", { name }))
    } else {
      toast(t("suggestions.added", { name }))
    }
  }

  return (
    <section className="flex flex-col gap-4 px-4">
      <div className="flex items-center gap-2">
        <Sparkles className="h-4 w-4 text-accent" />
        <h2 className="text-base font-semibold text-foreground">
          {t("suggestions.title")}
        </h2>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {items.map((item) => {
          const Icon = item.icon
          const checked = isChecked(item.id)
          return (
            <button
              key={item.id}
              onClick={() => handleToggle(item.id, item.name)}
              className={`group relative flex flex-col items-center gap-2 rounded-xl border bg-card p-3 shadow-sm transition-all active:scale-95 ${
                checked
                  ? "border-primary/40 shadow-md"
                  : "border-border/60 hover:border-primary/30 hover:shadow-md"
              }`}
            >
              {checked && (
                <div className="absolute -top-1.5 -right-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-primary">
                  <Check className="h-3 w-3 text-primary-foreground" />
                </div>
              )}
              <div
                className={`flex h-10 w-10 items-center justify-center rounded-lg ${item.color} transition-transform group-hover:scale-110`}
              >
                <Icon className="h-5 w-5" />
              </div>
              <span className="text-xs font-medium text-foreground text-center leading-tight">
                {item.name}
              </span>
            </button>
          )
        })}
      </div>
    </section>
  )
}
